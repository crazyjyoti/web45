from django.apps import AppConfig


class TaskmateAppConfig(AppConfig):
    name = 'taskmate_app'
